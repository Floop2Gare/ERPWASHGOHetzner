export const BRAND_NAME = 'Wash&Go App';
export const BRAND_BASELINE = '';
export const BRAND_FULL_TITLE = BRAND_NAME;
