# Front-end ERPWASHGO

Cette application fait partie du monorépo.

- Documentation et commandes: voir le `README.md` à la racine du dépôt.
- Développement depuis la racine:

```bash
npm run dev:web
```

Pour l’installation et le build, utilisez les scripts du monorépo.
