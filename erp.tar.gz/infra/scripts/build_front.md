# Build Front (texte)

- À la racine `/srv/erp`: `npm run install:all`
- Puis: `npm run build`
- Résultat: `/srv/erp/FRONT-END-ERP/FRONT-END-ERP/dist`
