# Scripts de déploiement (placeholders)

Ces fichiers sont des étapes décrites en texte. À exécuter manuellement ou à automatiser plus tard.

- pre_deploy.md: vérifs VM, utilisateur `erp`, UFW, installation Python/Node/PM2/Nginx/Certbot
- build_front.md: installation deps front + build Vite
- restart_backend.md: (re)démarrage du backend via PM2
- post_deploy.md: Nginx, Certbot, tests finaux
