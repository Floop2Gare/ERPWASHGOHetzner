# Backend ERPWASHGO (FastAPI)

Cette application fait partie du monorépo.

- Documentation et commandes: voir le `README.md` à la racine du dépôt.
- Démarrage API depuis la racine:

```bash
npm run dev:api
```

Pour l’installation Python, utilisez le venv et les requirements présents dans ce dossier, mais pilotez les commandes courantes depuis la racine.
