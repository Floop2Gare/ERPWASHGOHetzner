-- Migration 001: Schéma Initial
-- Date : 22 janvier 2025
-- Description : Création du schéma de base ERP Wash&Go
-- Status : ✅ APPLIQUÉE

-- Cette migration contient le schéma de base
-- Voir database/schema.sql pour le contenu complet

-- Note : Cette migration est déjà appliquée dans le schéma principal
-- Elle est conservée pour l'historique des migrations

